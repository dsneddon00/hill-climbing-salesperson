Obtained from here:

https://people.sc.fsu.edu/~jburkardt/datasets/cities/cities.html
